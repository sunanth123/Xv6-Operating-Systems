#include "types.h"
#include "user.h"


int main(void)
{
	int pid[100];
	int i;

	for(i = 0; i < 100; ++i)
	{
		pid[i] = fork();
		if(pid[i] == -1)
		{
			printf(1, "Performed %d Forks(max)\n", i);
			break;
		}
		if(pid[i] == 0)
		{
			sleep(9000000);
			exit();
		}
	}

	if(pid[0])
	{
		sleep(5000);
		printf(1, "Starting to kill....\n");

		for(int z = 0; z < (i-1); ++z)
		{
			printf(1, "Killing pid: %d\n", pid[z]);
			kill(pid[z]);
			sleep(10000);	
			while(wait() == -1)
			{
			}
			printf(1, "Reaped pid: %d\n", pid[z]);
			sleep(10000);
		}
	}
	exit();
}
